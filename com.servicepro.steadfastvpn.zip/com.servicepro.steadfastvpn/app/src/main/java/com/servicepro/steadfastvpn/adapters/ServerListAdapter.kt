package com.servicepro.steadfastvpn.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.servicepro.steadfastvpn.R
import com.servicepro.steadfastvpn.models.Server

class ServerListAdapter(
    private val servers: List<Server>,
    private val listener: OnServerSelectedListener
) : RecyclerView.Adapter<ServerListAdapter.ServerViewHolder>() {

    interface OnServerSelectedListener {
        fun onServerSelected(server: Server)
    }

    class ServerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val flag: ImageView = itemView.findViewById(R.id.server_flag)
        val country: TextView = itemView.findViewById(R.id.server_country)
        val address: TextView = itemView.findViewById(R.id.server_address)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ServerViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_server, parent, false)
        return ServerViewHolder(view)
    }

    override fun onBindViewHolder(holder: ServerViewHolder, position: Int) {
        val server = servers[position]
        holder.flag.setImageResource(server.flagResource)
        holder.country.text = server.country
        holder.address.text = server.address

        holder.itemView.setOnClickListener {
            listener.onServerSelected(server)
        }
    }

    override fun getItemCount() = servers.size
}