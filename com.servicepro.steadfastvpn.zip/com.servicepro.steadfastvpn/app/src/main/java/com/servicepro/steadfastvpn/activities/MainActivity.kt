package com.servicepro.steadfastvpn.activities

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.servicepro.steadfastvpn.R
import com.servicepro.steadfastvpn.databinding.ActivityMainBinding
import com.servicepro.steadfastvpn.models.Server
import com.servicepro.steadfastvpn.services.SteadfastVpnService
import com.servicepro.steadfastvpn.utils.PrefsHelper
import com.servicepro.steadfastvpn.utils.VpnHelper

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adView: AdView
    private var interstitialAd: InterstitialAd? = null
    private var currentServer: Server? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initAds()
        setupUI()
        loadCurrentServer()
    }

    private fun initAds() {
        // Banner Ad
        adView = binding.adView
        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)

        // Interstitial Ad
        InterstitialAd.load(this, getString(R.string.interstitial_ad_id), adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    interstitialAd = null
                }

                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                }
            })
    }

    private fun setupUI() {
        binding.connectButton.setOnClickListener {
            toggleVpnConnection()
        }

        binding.serverSelection.setOnClickListener {
            startActivity(Intent(this, ServerListActivity::class.java))
        }
    }

    private fun loadCurrentServer() {
        currentServer = PrefsHelper.getSelectedServer(this)
        currentServer?.let {
            binding.serverName.text = it.country
            binding.serverFlag.setImageResource(it.flagResource)
        }
    }

    private fun toggleVpnConnection() {
        if (VpnHelper.isVpnActive(this)) {
            disconnectVpn()
        } else {
            connectVpn()
        }
    }

    private fun connectVpn() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            startActivityForResult(intent, VPN_REQUEST_CODE)
        } else {
            startVpnService()
        }
    }

    private fun disconnectVpn() {
        startService(
            SteadfastVpnService.prepare(this)
                .setAction(SteadfastVpnService.ACTION_DISCONNECT)
        )
    }

    private fun startVpnService() {
        currentServer?.let { server ->
            startService(
                SteadfastVpnService.prepare(this)
                    .setAction(SteadfastVpnService.ACTION_CONNECT)
                    .putExtra(SteadfastVpnService.EXTRA_SERVER, server)
            )
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VPN_REQUEST_CODE && resultCode == RESULT_OK) {
            startVpnService()
        }
    }

    override fun onDestroy() {
        adView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val VPN_REQUEST_CODE = 1001
    }
}