package com.servicepro.steadfastvpn.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.servicepro.steadfastvpn.R
import com.servicepro.steadfastvpn.adapters.ServerListAdapter
import com.servicepro.steadfastvpn.databinding.ActivityServerListBinding
import com.servicepro.steadfastvpn.models.Server
import com.servicepro.steadfastvpn.utils.PrefsHelper

class ServerListActivity : AppCompatActivity(), ServerListAdapter.OnServerSelectedListener {

    private lateinit var binding: ActivityServerListBinding
    private lateinit var adapter: ServerListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityServerListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerView()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Select Server"
        binding.toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }
    }

    private fun setupRecyclerView() {
        val servers = listOf(
            Server("United States", "us1.steadfastvpn.com", "192.168.1.1", 24, "8.8.8.8", R.drawable.ic_us),
            Server("United Kingdom", "uk1.steadfastvpn.com", "192.168.2.1", 24, "8.8.4.4", R.drawable.ic_uk),
            Server("Japan", "jp1.steadfastvpn.com", "192.168.3.1", 24, "1.1.1.1", R.drawable.ic_jp),
            Server("Germany", "de1.steadfastvpn.com", "192.168.4.1", 24, "1.0.0.1", R.drawable.ic_de)
        )

        adapter = ServerListAdapter(servers, this)
        binding.serversRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.serversRecyclerView.adapter = adapter
    }

    override fun onServerSelected(server: Server) {
        PrefsHelper.setSelectedServer(this, server)
        setResult(RESULT_OK)
        finish()
    }
}