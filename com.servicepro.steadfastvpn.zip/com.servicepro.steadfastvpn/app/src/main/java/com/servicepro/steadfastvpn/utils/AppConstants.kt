package com.servicepro.steadfastvpn.utils

object AppConstants {
    // SharedPreferences
    const val PREFS_NAME = "SteadfastVpnPrefs"
    const val KEY_VPN_STATUS = "vpn_status"
    const val KEY_SELECTED_SERVER = "selected_server"
    const val KEY_AUTO_CONNECT = "auto_connect"

    // OneSignal
    const val ONE_SIGNAL_APP_ID = "your-onesignal-app-id"

    // AdMob
    const val ADMOB_APP_ID = "ca-app-pub-3940256099942544~3347511713"
    const val BANNER_AD_ID = "ca-app-pub-3940256099942544/6300978111"
    const val INTERSTITIAL_AD_ID = "ca-app-pub-3940256099942544/1033173712"

    // VPN
    const val VPN_CONFIG = "vpn_config"
    const val ACTION_VPN_STATE = "vpn_state"
    const val EXTRA_VPN_STATE = "vpn_state"
}