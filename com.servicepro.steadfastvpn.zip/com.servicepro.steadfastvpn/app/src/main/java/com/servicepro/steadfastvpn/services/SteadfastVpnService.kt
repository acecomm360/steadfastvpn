package com.servicepro.steadfastvpn.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.servicepro.steadfastvpn.R
import com.servicepro.steadfastvpn.activities.MainActivity
import com.servicepro.steadfastvpn.models.Server
import com.servicepro.steadfastvpn.utils.AppConstants.ACTION_VPN_STATE
import com.servicepro.steadfastvpn.utils.AppConstants.EXTRA_VPN_STATE
import com.servicepro.steadfastvpn.utils.PrefsHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SteadfastVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private val notificationId = 1
    private val channelId = "vpn_service_channel"

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val server = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_SERVER, Server::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_SERVER)
                }
                server?.let { connect(it) }
            }
            ACTION_DISCONNECT -> disconnect()
        }
        return START_STICKY
    }

    private fun connect(server: Server) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Create VPN interface
                val builder = Builder()
                    .setSession("SteadfastVPN")
                    .addAddress(server.ipAddress, server.prefixLength)
                    .addDnsServer(server.dns)
                    .addRoute("0.0.0.0", 0)

                vpnInterface = builder.establish()

                // Start foreground service
                startForeground(notificationId, createNotification())

                // Update connection state
                PrefsHelper.setVpnStatus(this@SteadfastVpnService, true)
                sendBroadcast(
                    Intent(ACTION_VPN_STATE).putExtra(
                        EXTRA_VPN_STATE,
                        true
                    )
                )

                // Here you would implement the actual VPN protocol
                // For OpenVPN, you would use OpenVpnService implementation
                // This is just a basic example

            } catch (e: Exception) {
                disconnect()
            }
        }
    }

    private fun disconnect() {
        try {
            vpnInterface?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            vpnInterface = null
            stopForeground(true)
            stopSelf()

            // Update connection state
            PrefsHelper.setVpnStatus(this, false)
            sendBroadcast(
                Intent(ACTION_VPN_STATE).putExtra(
                    EXTRA_VPN_STATE,
                    false
                )
            )
        }
    }

    private fun createNotification(): Notification {
        createNotificationChannel()

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("SteadfastVPN")
            .setContentText("VPN is connected")
            .setSmallIcon(R.drawable.ic_vpn)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "VPN Service",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "VPN connection status"
            }

            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        disconnect()
        super.onDestroy()
    }

    companion object {
        const val ACTION_CONNECT = "connect"
        const val ACTION_DISCONNECT = "disconnect"
        const val EXTRA_SERVER = "server"

        fun prepare(context: android.content.Context): Intent {
            return Intent(context, SteadfastVpnService::class.java)
        }
    }
}