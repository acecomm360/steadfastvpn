package com.servicepro.steadfastvpn.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Server(
    val country: String,
    val address: String,
    val ipAddress: String,
    val preflixLength: Int,
    val dns: String,
    val flagResource: Int
) : Parcelable