package com.servicepro.steadfastvpn.utils

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

object VpnHelper {

    fun isVpnActive(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val network = connectivityManager.activeNetwork
            val capabilities = connectivityManager.getNetworkCapabilities(network)
            return capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        } else {
            @Suppress("DEPRECATION")
            val networks = connectivityManager.allNetworks
            return networks.any { network ->
                val caps = connectivityManager.getNetworkCapabilities(network)
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
            }
        }
    }
}