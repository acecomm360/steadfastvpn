package com.servicepro.steadfastvpn.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.servicepro.steadfastvpn.services.SteadfastVpnService
import com.servicepro.steadfastvpn.utils.PrefsHelper

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && PrefsHelper.isAutoConnect(context)) {
            val server = PrefsHelper.getSelectedServer(context)
            server?.let {
                context.startService(
                    SteadfastVpnService.prepare(context)
                        .setAction(SteadfastVpnService.ACTION_CONNECT)
                        .putExtra(SteadfastVpnService.EXTRA_SERVER, it)
                )
            }
        }
    }
}