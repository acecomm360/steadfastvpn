package com.servicepro.steadfastvpn.utils

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.servicepro.steadfastvpn.models.Server

object PrefsHelper {

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(AppConstants.PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun setVpnStatus(context: Context, isConnected: Boolean) {
        getPrefs(context).edit().putBoolean(AppConstants.KEY_VPN_STATUS, isConnected).apply()
    }

    fun isVpnActive(context: Context): Boolean {
        return getPrefs(context).getBoolean(AppConstants.KEY_VPN_STATUS, false)
    }

    fun setSelectedServer(context: Context, server: Server) {
        val json = Gson().toJson(server)
        getPrefs(context).edit().putString(AppConstants.KEY_SELECTED_SERVER, json).apply()
    }

    fun getSelectedServer(context: Context): Server? {
        val json = getPrefs(context).getString(AppConstants.KEY_SELECTED_SERVER, null)
        return Gson().fromJson(json, Server::class.java)
    }

    fun setAutoConnect(context: Context, autoConnect: Boolean) {
        getPrefs(context).edit().putBoolean(AppConstants.KEY_AUTO_CONNECT, autoConnect).apply()
    }

    fun isAutoConnect(context: Context): Boolean {
        return getPrefs(context).getBoolean(AppConstants.KEY_AUTO_CONNECT, false)
    }
}